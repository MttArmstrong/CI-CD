project = "package"
extensions = ["myst_parser"]
source_suffix = [".rst", ".md"]
html_theme = "furo"
